<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$route['default_controller'] = 'Auth/index';
$route['login'] = 'Auth/index';
$route['404_override'] = 'Auth/notfound';
$route['translate_uri_dashes'] = FALSE;
$route['loginauth'] = 'Auth/loginauth';
$route['dashboard'] = 'Dashboard/index';
$route['logout'] = 'Dashboard/logout';
$route['changepassword'] = 'Dashboard/changepassword';
$route['changepsw'] = 'Dashboard/changepsw';

$route['stafflist'] = 'Staff/stafflist';
$route['addnewstaff'] = 'Staff/addnew_staff';
$route['insert_staff'] = 'Staff/insert_staff';
$route['editstaff/(:any)'] = 'Staff/editstaff/$1';
$route['updatestaffdata'] = 'Staff/updatestaffdata';

$route['deletestaff'] = 'Staff/deletestaff';

$route['agentlist'] = 'Agent/agentlist';
$route['addnewagent'] = 'Agent/addnewagent';
$route['insert_agent'] = 'Agent/insert_agent';
$route['editagent/(:any)'] = 'Agent/editagent/$1';
$route['updateagentdata'] = 'Agent/updateagentdata';

$route['joblist'] = 'Jobs/joblist';
$route['addnewjob'] = 'Jobs/addnewjob';
$route['insert_job'] = 'Jobs/insert_job';
$route['deletejob'] = 'Jobs/deletejob';
$route['editjob/(:any)'] = 'Jobs/editjob/$1';
$route['update_job'] = 'Jobs/update_job';


$route['placementlist'] = 'Placements/placementlist';

$route['candidatelist'] = 'Candidate/candidatelist';
$route['addnewcandidate'] = 'Candidate/addnewcandidate';
$route['insert_candidate'] = 'Candidate/insert_candidate';
$route['editcandidate/(:any)'] = 'Candidate/editcandidate/$1';
$route['updatecandidatedata'] = 'Candidate/updatecandidatedata';



